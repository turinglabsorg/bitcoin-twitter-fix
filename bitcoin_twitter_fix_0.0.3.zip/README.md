# Bitcoin Twitter Fix

Annoyed about the Dogecoin logo applied on Twitter?!

Install this extension and solve the problem mate.

Install it as unpacked extension or wait for official link!